
import React from 'react';
import { PdfFile } from '../App';
import PdfIcon from './icons/PdfIcon';

interface PdfCardProps {
  pdf: PdfFile;
}

const PdfCard: React.FC<PdfCardProps> = ({ pdf }) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString([], {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <a
      href={pdf.pdfDataUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="relative flex flex-col bg-gray-900 border border-gray-800 rounded-lg text-left hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-transparent focus:ring-gray-600 transition-all duration-200 transform hover:-translate-y-1 w-full h-full overflow-hidden p-4 group"
      aria-label={`View PDF titled ${pdf.title}`}
    >
      <div className="flex-grow">
        <h3 className="font-bold text-lg text-gray-200 mb-2 truncate">{pdf.title}</h3>
        <p className="text-xs text-gray-500">Created: {formatDate(pdf.createdAt)}</p>
      </div>
      <div className="mt-4 text-center">
        <PdfIcon className="h-16 w-16 text-gray-700 group-hover:text-red-500 transition-colors duration-200 mx-auto" />
      </div>
    </a>
  );
};

export default PdfCard;
