
import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import EllipsisVerticalIcon from './icons/EllipsisVerticalIcon';
import BottomToolbar from './BottomToolbar';
import EditorMenu from './EditorMenu';
import { Note } from '../App';
import EditIcon from './icons/EditIcon';
import RestoreIcon from './icons/RestoreIcon';
import FindBar from './FindBar';

interface EditorPageProps {
  note: Note;
  onBack: () => void;
  onSave: (note: Note) => void;
  onAutoUpdate: (note: Note) => void;
  onTrash: () => void;
  onDeletePermanently: () => void;
  onToggleArchive: () => void;
  onToggleFavorite: () => void;
  onToggleLock: () => void;
  onTogglePin: () => void;
  onShowVersions: () => void;
  onConvertToPdf: () => void;
  onOpenRenameModal: () => void;
  onRestore?: () => void;
  isTrashNote?: boolean;
  isNewNote?: boolean;
  editorFont: 'sans' | 'serif' | 'mono';
  editorFontSize: 'small' | 'medium' | 'large';
  showWordCount: boolean;
}

const FONT_SIZE_MAP = {
  small: 'text-base',
  medium: 'text-lg',
  large: 'text-xl',
};

const FONT_FAMILY_MAP = {
  sans: 'font-sans',
  serif: 'font-serif',
  mono: 'font-mono',
};


const EditorPage: React.FC<EditorPageProps> = ({ 
  note, onBack, onSave, onAutoUpdate, onTrash, onDeletePermanently, onToggleArchive, onToggleFavorite, onToggleLock, onTogglePin, onShowVersions,
  onConvertToPdf, onOpenRenameModal, onRestore, isTrashNote = false, isNewNote = false, editorFont, editorFontSize, showWordCount,
}) => {
  const [isEditing, setIsEditing] = useState(isNewNote && !isTrashNote);
  const [bottomInset, setBottomInset] = useState(0);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const editorRef = useRef<HTMLDivElement>(null);
  
  const [title, setTitle] = useState(note.title);
  const [content, setContent] = useState(note.content);
  const isDirty = useRef(false);


  // State for "Find" feature
  const [isFinding, setIsFinding] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [matches, setMatches] = useState<HTMLElement[]>([]);
  const [currentMatchIndex, setCurrentMatchIndex] = useState(-1);

  // Sync local state with note prop when a different note is loaded
  useEffect(() => {
    setTitle(note.title);
    setContent(note.content);
    if (editorRef.current) {
        editorRef.current.innerHTML = note.content;
    }
    isDirty.current = false;
  }, [note.id, note.title]); // Added note.title to handle rename updates

  // Debounced auto-save effect
  useEffect(() => {
    if (!isDirty.current) {
        return;
    }
    const handler = setTimeout(() => {
        onAutoUpdate({ ...note, title, content });
        isDirty.current = false; // Reset dirty flag after auto-save
    }, 1500); // 1.5 seconds delay

    return () => {
        clearTimeout(handler);
    };
  }, [title, content, note, onAutoUpdate]);


  useEffect(() => {
    const handleResize = () => {
      if (window.visualViewport) {
        const inset = window.innerHeight - window.visualViewport.height;
        setBottomInset(inset > 50 ? inset : 0);
      }
    };

    const vv = window.visualViewport;
    if (vv) {
      vv.addEventListener('resize', handleResize);
      handleResize();
      return () => vv.removeEventListener('resize', handleResize);
    }
  }, []);
  
  // Checklist item interaction handler
  useEffect(() => {
    const editor = editorRef.current;
    if (!editor || !isEditing) return;

    const handleClick = (e: MouseEvent) => {
        const target = e.target as HTMLElement;
        if (target.tagName === 'INPUT' && target.getAttribute('type') === 'checkbox' && target.parentElement?.classList.contains('checklist-item')) {
            const checkbox = target as HTMLInputElement;
            // This is visual-only; the actual 'checked' state is saved with innerHTML.
            // We need to explicitly set the attribute to ensure it's saved.
            if (checkbox.checked) {
                checkbox.setAttribute('checked', 'true');
            } else {
                checkbox.removeAttribute('checked');
            }
            // Trigger input event to mark as dirty for saving
            editor.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
        }
    };

    editor.addEventListener('click', handleClick);
    return () => {
        if (editor) {
            editor.removeEventListener('click', handleClick);
        }
    };
  }, [isEditing]);

  const handleSave = () => {
    const finalContent = editorRef.current?.innerHTML || content;
    onSave({ ...note, title, content: finalContent });
  };
  
  const removeHighlights = useCallback(() => {
    if (!editorRef.current) return;
    const marks = editorRef.current.querySelectorAll('mark.search-highlight');
    marks.forEach(mark => {
        const parent = mark.parentNode;
        if (parent) {
            parent.insertBefore(document.createTextNode(mark.textContent || ''), mark);
            parent.removeChild(mark);
        }
    });
    // Merge adjacent text nodes
    editorRef.current.normalize();
  }, []);
  
  const handleCloseFind = useCallback(() => {
    removeHighlights();
    setIsFinding(false);
    setSearchQuery('');
    setMatches([]);
    setCurrentMatchIndex(-1);
  }, [removeHighlights]);

  // Reset find state if page is hidden (e.g., user switches tabs)
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden' && isFinding) {
        handleCloseFind();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [isFinding, handleCloseFind]);


  // Cleanup highlights when the editor is closed for any reason
  useEffect(() => {
    return () => {
      removeHighlights();
    };
  }, [removeHighlights]);

  const performSearch = useCallback(() => {
    if (!editorRef.current) return;
    
    removeHighlights();

    if (!searchQuery) {
      setMatches([]);
      setCurrentMatchIndex(-1);
      return;
    }
    
    const textNodes: Text[] = [];
    const treeWalker = document.createTreeWalker(editorRef.current, NodeFilter.SHOW_TEXT);
    let node;
    while(node = treeWalker.nextNode()) {
        if (node.parentElement && !['SCRIPT', 'STYLE', 'MARK'].includes(node.parentElement.tagName.toUpperCase())) {
            textNodes.push(node as Text);
        }
    }

    const regex = new RegExp(searchQuery.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'), 'gi');
    const newMatches: HTMLElement[] = [];

    textNodes.forEach(textNode => {
      const text = textNode.nodeValue || '';
      const parent = textNode.parentNode;
      if (!parent || !text) return;

      const matchesInNode = [...text.matchAll(regex)];
      if (matchesInNode.length > 0) {
          const fragment = document.createDocumentFragment();
          let lastIndex = 0;

          matchesInNode.forEach(match => {
              const index = match.index!;
              if (index > lastIndex) {
                  fragment.appendChild(document.createTextNode(text.substring(lastIndex, index)));
              }
              const mark = document.createElement('mark');
              mark.className = 'search-highlight';
              mark.textContent = match[0];
              fragment.appendChild(mark);
              newMatches.push(mark);
              lastIndex = index + match[0].length;
          });

          if (lastIndex < text.length) {
              fragment.appendChild(document.createTextNode(text.substring(lastIndex)));
          }
          parent.replaceChild(fragment, textNode);
      }
    });

    setMatches(newMatches);
    setCurrentMatchIndex(newMatches.length > 0 ? 0 : -1);
  }, [searchQuery, removeHighlights]);


  useEffect(() => {
    if (isFinding) {
      const handler = setTimeout(() => {
        performSearch();
      }, 200);
      return () => clearTimeout(handler);
    }
  }, [searchQuery, isFinding, performSearch]);


  useEffect(() => {
    if (matches.length === 0) return;
    
    matches.forEach((match, index) => {
        match.classList.toggle('current-search-highlight', index === currentMatchIndex);
    });

    if (currentMatchIndex >= 0 && matches[currentMatchIndex]) {
        matches[currentMatchIndex].scrollIntoView({
            behavior: 'smooth',
            block: 'center'
        });
    }
  }, [currentMatchIndex, matches]);

  const handleFind = () => setIsFinding(true);
  
  const handleNextMatch = () => {
    if (matches.length > 0) {
      setCurrentMatchIndex(prev => (prev + 1) % matches.length);
    }
  };

  const handlePrevMatch = () => {
    if (matches.length > 0) {
      setCurrentMatchIndex(prev => (prev - 1 + matches.length) % matches.length);
    }
  };


  const showToolbar = isEditing && !isTrashNote;

  const handleContentInput = (e: React.FormEvent<HTMLDivElement>) => {
    isDirty.current = true;
    setContent(e.currentTarget.innerHTML);
    if (isFinding) handleCloseFind();
  };
  
  const wordCount = useMemo(() => {
    if (!showWordCount) return { words: 0, characters: 0 };
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = content;
    const text = tempDiv.textContent || tempDiv.innerText || '';
    const words = text.trim() ? text.trim().split(/\s+/).length : 0;
    return {
      words: words,
      characters: text.length,
    };
  }, [content, showWordCount]);

  return (
    <div className="fixed inset-0 bg-white dark:bg-black z-50 animate-fadeIn flex flex-col">
      <header className="bg-white/80 dark:bg-black/80 backdrop-blur-lg z-30 border-b border-gray-200 dark:border-gray-900 flex-shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-[auto_1fr_auto] items-center h-16 gap-x-4">
            <div>
              <button
                type="button"
                onClick={onBack}
                className="p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-black focus:ring-gray-500 transition-colors duration-200"
                aria-label="Go back to notes"
              >
                <ArrowLeftIcon className="h-6 w-6" />
              </button>
            </div>

            <h1
              aria-label="Note title"
              className="text-lg font-semibold text-gray-800 dark:text-gray-200 truncate text-center px-2 py-1"
            >{title}</h1>
            
            <div className="flex items-center space-x-2">
              {isTrashNote ? (
                 <button
                    type="button"
                    onClick={onRestore}
                    className="flex items-center space-x-2 px-3 py-1.5 rounded-md text-sm font-semibold text-gray-800 dark:text-gray-200 bg-gray-200 dark:bg-gray-800 hover:bg-gray-300 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-black focus:ring-gray-500 transition-colors duration-200"
                    aria-label="Restore note"
                >
                    <RestoreIcon className="h-5 w-5" />
                    <span>Restore</span>
                </button>
              ) : isEditing ? (
                <>
                  <button
                    type="button"
                    onClick={handleSave}
                    className="px-4 py-2 bg-gray-800 text-white dark:bg-gray-200 dark:text-gray-900 text-sm font-medium rounded-md hover:bg-gray-700 dark:hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-black focus:ring-gray-500 dark:focus:ring-gray-400 transition-colors"
                    aria-label="Save note"
                  >
                    Save
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsMenuOpen(true)}
                    className="p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-black focus:ring-gray-500 transition-colors duration-200"
                    aria-label="More options"
                  >
                    <EllipsisVerticalIcon className="h-6 w-6" />
                  </button>
                </>
              ) : (
                  <button
                    type="button"
                    onClick={() => setIsEditing(true)}
                    className="p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-black focus:ring-gray-500 transition-colors duration-200"
                    aria-label="Edit note"
                  >
                    <EditIcon className="h-6 w-6" />
                  </button>
              )}
            </div>
          </div>
        </div>
      </header>
      
      {isFinding && (
        <FindBar
          searchQuery={searchQuery}
          onSearchQueryChange={setSearchQuery}
          onClose={handleCloseFind}
          onNext={handleNextMatch}
          onPrev={handlePrevMatch}
          currentMatchIndex={currentMatchIndex}
          totalMatches={matches.length}
        />
      )}

      <main 
        className={`flex-grow overflow-y-auto p-4 sm:p-6 lg:p-8 ${isTrashNote ? 'select-none' : ''}`}
      >
        <div 
          ref={editorRef}
          className={`max-w-3xl mx-auto w-full bg-transparent text-gray-800 dark:text-gray-300 focus:outline-none prose-editor ${FONT_SIZE_MAP[editorFontSize]} ${FONT_FAMILY_MAP[editorFont]}`}
          contentEditable={isEditing}
          onInput={handleContentInput}
          suppressContentEditableWarning={true}
          autoFocus={isEditing}
          aria-label="Note content"
          role="textbox"
          aria-multiline="true"
          data-placeholder="Start writing your note here..."
          style={{ whiteSpace: 'pre-wrap' }}
        ></div>
        <style>{`
          [contentEditable=true][data-placeholder]:empty:before {
            content: attr(data-placeholder);
            color: #9ca3af; /* gray-400 */
            pointer-events: none;
            display: block;
          }
          .dark [contentEditable=true][data-placeholder]:empty:before {
            color: #4b5563; /* dark:gray-600 */
          }
          [contentEditable=true] ul {
            list-style-type: disc;
            padding-left: 2rem;
          }
          [contentEditable=true] ol {
            list-style-type: decimal;
            padding-left: 2rem;
          }
          .checklist {
            list-style: none !important;
            padding-left: 0 !important;
          }
          .checklist-item {
            display: flex;
            align-items: center;
            margin-bottom: 0.5em;
          }
          .checklist-item input[type=checkbox] {
            width: 1.25em;
            height: 1.25em;
            margin-right: 0.75em;
            flex-shrink: 0;
            appearance: none;
            border: 2px solid #6b7280; /* gray-500 */
            border-radius: 4px;
            cursor: pointer;
            vertical-align: middle;
          }
          .dark .checklist-item input[type=checkbox] {
             border-color: #9ca3af; /* dark:gray-400 */
          }
          .checklist-item input[type=checkbox]:checked {
            background-color: #4f46e5; /* indigo-600 */
            border-color: #4f46e5;
            background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.207 4.793a1 1 0 010 1.414l-5 5a1 1 0 01-1.414 0l-2-2a1 1 0 011.414-1.414L6.5 9.086l4.293-4.293a1 1 0 011.414 0z'/%3e%3c/svg%3e");
          }
          .checklist-item .editable-text {
            flex-grow: 1;
          }
          .checklist-item input[type=checkbox]:checked + .editable-text {
            text-decoration: line-through;
            color: #6b7280; /* gray-500 */
          }
          .dark .checklist-item input[type=checkbox]:checked + .editable-text {
            color: #4b5563; /* dark:gray-600 */
          }
          ::selection {
            background-color: #a5b4fc; /* indigo-300 */
          }
          .dark ::selection {
            background-color: #525252;
          }
          .search-highlight {
            background-color: #fef08a; /* yellow-200 */
            color: black;
            border-radius: 2px;
          }
          .dark .search-highlight {
            background-color: #facc15; /* dark:yellow-400 */
          }
          .current-search-highlight {
            background-color: #fcd34d; /* yellow-300 */
          }
          .dark .current-search-highlight {
            background-color: #fb923c; /* dark:orange-400 */
          }
          mark.highlight {
            background-color: #fef08a;
            color: inherit;
          }
          .dark mark.highlight {
            background-color: #facc15;
          }
          .prose-editor h1 {
            font-size: 2em;
            font-weight: bold;
            margin-bottom: 0.8em;
          }
          .prose-editor h2 {
            font-size: 1.5em;
            font-weight: bold;
            margin-bottom: 0.6em;
          }
        `}</style>
      </main>
      
      {showToolbar && (
        <div className="flex-shrink-0">
            <BottomToolbar bottomInset={bottomInset} />
        </div>
      )}

      {showWordCount && isEditing && (
        <div className="flex-shrink-0 text-xs text-gray-500 dark:text-gray-400 text-center py-1 border-t border-gray-200 dark:border-gray-800">
            {wordCount.words} words, {wordCount.characters} characters
        </div>
      )}
      
      {
        <EditorMenu
          isOpen={isMenuOpen}
          onClose={() => setIsMenuOpen(false)}
          onTrash={onTrash}
          onDeletePermanently={onDeletePermanently}
          onToggleArchive={onToggleArchive}
          onToggleFavorite={onToggleFavorite}
          onToggleLock={onToggleLock}
          onTogglePin={onTogglePin}
          onShowVersions={onShowVersions}
          onFind={handleFind}
          onConvertToPdf={onConvertToPdf}
          onRename={onOpenRenameModal}
          isArchived={note.isArchived}
          isFavorite={note.isFavorite}
          isLocked={note.isLocked}
          isPinned={note.isPinned}
          note={note}
        />
      }
    </div>
  );
};

export default EditorPage;
