import React, { useState, useRef, useLayoutEffect, useEffect, useCallback } from 'react';
import { Note } from '../App';
import ChevronDownIcon from './icons/ChevronDownIcon';

declare const jspdf: any;
declare const html2canvas: any;

interface PdfPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (noteId: string, title: string, pdfDataUrl: string) => void;
  note: Note;
}

type PageSize = 'A4' | 'Letter' | 'Legal';
type FontSize = 10 | 12 | 14 | 16;

const PAGE_DIMENSIONS_MM: Record<PageSize, { width: number; height: number }> = {
  A4: { width: 210, height: 297 },
  Letter: { width: 215.9, height: 279.4 },
  Legal: { width: 215.9, height: 355.6 },
};

const PADDING_MM = 15;

const mmToPx = (mm: number) => {
    const div = document.createElement('div');
    div.style.position = 'absolute';
    div.style.width = `${mm}mm`;
    document.body.appendChild(div);
    const px = div.offsetWidth;
    document.body.removeChild(div);
    return px;
};


const PdfPreviewModal: React.FC<PdfPreviewModalProps> = ({ isOpen, onClose, onSave, note }) => {
  const [pageSize, setPageSize] = useState<PageSize>('A4');
  const [fontSize, setFontSize] = useState<FontSize>(12);
  const [isSaving, setIsSaving] = useState(false);
  const [isGenerating, setIsGenerating] = useState(true);
  const [totalPages, setTotalPages] = useState(0);
  const [pageContentHeightPx, setPageContentHeightPx] = useState(0);
  const [scale, setScale] = useState(1);
  
  const [isPageSizeDropdownOpen, setIsPageSizeDropdownOpen] = useState(false);
  const [isFontSizeDropdownOpen, setIsFontSizeDropdownOpen] = useState(false);

  const previewContainerRef = useRef<HTMLDivElement>(null);
  const pageSizeDropdownRef = useRef<HTMLDivElement>(null);
  const fontSizeDropdownRef = useRef<HTMLDivElement>(null);

  const pageDims = PAGE_DIMENSIONS_MM[pageSize];

  useLayoutEffect(() => {
    const updateScale = () => {
      if (!previewContainerRef.current || !isOpen) return;
      const containerWidth = previewContainerRef.current.clientWidth;
      const previewWidth = mmToPx(pageDims.width);
      
      const effectiveContainerWidth = containerWidth - 40; 
      
      if (previewWidth > effectiveContainerWidth) {
        setScale(effectiveContainerWidth / previewWidth);
      } else {
        setScale(1);
      }
    };

    if (isOpen) {
        const timer = setTimeout(updateScale, 50);
        window.addEventListener('resize', updateScale);
        return () => {
            clearTimeout(timer);
            window.removeEventListener('resize', updateScale);
        };
    }
  }, [isOpen, pageSize, pageDims.width]);
  
  const closeDropdowns = useCallback((event: MouseEvent) => {
    if (pageSizeDropdownRef.current && !pageSizeDropdownRef.current.contains(event.target as Node)) {
        setIsPageSizeDropdownOpen(false);
    }
    if (fontSizeDropdownRef.current && !fontSizeDropdownRef.current.contains(event.target as Node)) {
        setIsFontSizeDropdownOpen(false);
    }
  }, []);

  useEffect(() => {
    if (isOpen) {
      document.addEventListener('mousedown', closeDropdowns);
    }
    return () => {
        document.removeEventListener('mousedown', closeDropdowns);
    };
  }, [isOpen, closeDropdowns]);


  useEffect(() => {
    if (!isOpen) return;

    setIsGenerating(true);
    const timer = setTimeout(() => {
        const pageContentHeightMm = pageDims.height - PADDING_MM * 2;
        const pageContentHeight = mmToPx(pageContentHeightMm);
        setPageContentHeightPx(pageContentHeight);

        const measurer = document.createElement('div');
        measurer.style.position = 'absolute';
        measurer.style.left = '-9999px';
        measurer.style.width = `${mmToPx(pageDims.width - PADDING_MM * 2)}px`;
        measurer.style.visibility = 'hidden';
        
        const measurerContent = document.createElement('div');
        measurerContent.className = 'prose-preview';
        measurerContent.style.fontSize = `${fontSize}pt`;
        measurerContent.innerHTML = note.content;
        measurer.appendChild(measurerContent);
        
        document.body.appendChild(measurer);
        
        const totalHeight = measurer.scrollHeight;
        const numPages = totalHeight > 0 ? Math.ceil(totalHeight / pageContentHeight) : 1;
        
        setTotalPages(numPages);
        document.body.removeChild(measurer);
        setIsGenerating(false);

    }, 100);

    return () => clearTimeout(timer);

  }, [isOpen, note.content, pageSize, fontSize, pageDims]);

  const handleSave = async () => {
    if (isSaving || totalPages === 0) return;
    setIsSaving(true);
    try {
        const { jsPDF } = jspdf;
        const pdf = new jsPDF({
            orientation: 'portrait',
            unit: 'mm',
            format: pageSize.toLowerCase()
        });

        const captureTarget = document.createElement('div');
        captureTarget.style.position = 'absolute';
        captureTarget.style.left = '-9999px';
        captureTarget.style.background = 'white';
        captureTarget.style.width = `${pageDims.width}mm`;
        
        const captureContent = document.createElement('div');
        captureContent.className = 'prose-preview';
        captureContent.style.padding = `${PADDING_MM}mm`;
        captureContent.style.fontSize = `${fontSize}pt`;
        captureContent.innerHTML = note.content;
        
        captureTarget.appendChild(captureContent);
        document.body.appendChild(captureTarget);
        
        const fullCanvas = await html2canvas(captureTarget, {
            scale: 2,
            useCORS: true,
        });

        document.body.removeChild(captureTarget);

        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = pdf.internal.pageSize.getHeight();
        const canvasSliceHeight = (pdfHeight / pdfWidth) * fullCanvas.width;

        for (let i = 0; i < totalPages; i++) {
            if (i > 0) pdf.addPage();
            
            const sliceCanvas = document.createElement('canvas');
            sliceCanvas.width = fullCanvas.width;
            sliceCanvas.height = canvasSliceHeight;
            const ctx = sliceCanvas.getContext('2d');
            
            if (ctx) {
                ctx.drawImage(
                    fullCanvas,
                    0, i * canvasSliceHeight, // source y
                    fullCanvas.width, canvasSliceHeight, // source width, height
                    0, 0, // dest x, y
                    fullCanvas.width, canvasSliceHeight // dest width, height
                );
                
                const imgData = sliceCanvas.toDataURL('image/png');
                pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
            }
        }
        
        const pdfDataUrl = pdf.output('datauristring');
        onSave(note.id, note.title, pdfDataUrl);

        pdf.save(`${note.title}.pdf`);

    } catch (error) {
        console.error('Failed to generate PDF', error);
        alert('Could not generate PDF. Please try again.');
    } finally {
        setIsSaving(false);
    }
  };
  
  const pageSizes: PageSize[] = ['A4', 'Letter', 'Legal'];
  const fontSizes: FontSize[] = [10, 12, 14, 16];
  
  const handlePageSizeSelect = (size: PageSize) => {
    setPageSize(size);
    setIsPageSizeDropdownOpen(false);
  };
  const handleFontSizeSelect = (size: FontSize) => {
    setFontSize(size);
    setIsFontSizeDropdownOpen(false);
  };
  
  return (
    <div
      className={`fixed inset-0 z-[60] flex items-center justify-center bg-black bg-opacity-70 backdrop-blur-sm transition-opacity duration-300 ease-in-out ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
      aria-labelledby="pdf-modal-title" role="dialog" aria-modal={isOpen} onClick={onClose}
    >
      <div
        className={`bg-gray-900 rounded-lg shadow-xl w-full h-full max-w-4xl max-h-[90vh] m-4 flex flex-col transform transition-all duration-300 ease-in-out ${isOpen ? 'scale-100 opacity-100' : 'scale-95 opacity-0'}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-4 sm:p-6 border-b border-gray-800 flex items-center justify-between gap-4">
          <h2 id="pdf-modal-title" className="text-xl font-bold text-white truncate pr-4 flex-shrink">
            PDF Preview: {note.title}
          </h2>
          <div className="flex items-center gap-2 flex-shrink-0">
            {/* Font size dropdown */}
            <div ref={fontSizeDropdownRef} className="relative">
                <button type="button" onClick={() => setIsFontSizeDropdownOpen(!isFontSizeDropdownOpen)} className="flex items-center justify-between w-28 px-3 py-2 bg-gray-800 border border-gray-700 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-gray-500" aria-haspopup="listbox" aria-expanded={isFontSizeDropdownOpen}>
                    <span>{fontSize} pt</span>
                    <ChevronDownIcon className={`h-5 w-5 text-gray-400 transition-transform duration-200 ${isFontSizeDropdownOpen ? 'rotate-180' : ''}`} />
                </button>
                {isFontSizeDropdownOpen && (
                    <ul className="absolute right-0 mt-2 w-28 bg-gray-800 border border-gray-700 rounded-md shadow-lg z-10 animate-fadeIn" role="listbox">
                        {fontSizes.map((size) => (
                            <li key={size}>
                                <button type="button" onClick={() => handleFontSizeSelect(size)} className="w-full text-left px-3 py-2 text-sm text-white hover:bg-gray-700" role="option" aria-selected={size === fontSize}>
                                    {size} pt
                                </button>
                            </li>
                        ))}
                    </ul>
                )}
            </div>
            {/* Page size dropdown */}
            <div ref={pageSizeDropdownRef} className="relative">
                <button type="button" onClick={() => setIsPageSizeDropdownOpen(!isPageSizeDropdownOpen)} className="flex items-center justify-between w-28 px-3 py-2 bg-gray-800 border border-gray-700 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-gray-500" aria-haspopup="listbox" aria-expanded={isPageSizeDropdownOpen}>
                    <span>{pageSize}</span>
                    <ChevronDownIcon className={`h-5 w-5 text-gray-400 transition-transform duration-200 ${isPageSizeDropdownOpen ? 'rotate-180' : ''}`} />
                </button>
                {isPageSizeDropdownOpen && (
                    <ul className="absolute right-0 mt-2 w-28 bg-gray-800 border border-gray-700 rounded-md shadow-lg z-10 animate-fadeIn" role="listbox">
                        {pageSizes.map((size) => (
                            <li key={size}>
                                <button type="button" onClick={() => handlePageSizeSelect(size)} className="w-full text-left px-3 py-2 text-sm text-white hover:bg-gray-700" role="option" aria-selected={size === pageSize}>
                                    {size}
                                </button>
                            </li>
                        ))}
                    </ul>
                )}
            </div>
          </div>
        </div>
        <div ref={previewContainerRef} className="flex-grow bg-gray-800/50 p-4 sm:p-8 overflow-auto flex justify-center items-start">
            {isGenerating ? (
                <div className="text-gray-400">Generating preview...</div>
            ) : (
                <div style={{ transform: `scale(${scale})`, transformOrigin: 'top center' }} className="transition-transform duration-200 space-y-4">
                    {Array.from({ length: totalPages }).map((_, i) => (
                        <div key={i} className="bg-white shadow-lg text-black overflow-hidden" style={{ width: `${pageDims.width}mm`, height: `${pageDims.height}mm` }}>
                           <div className="prose-preview" style={{ padding: `${PADDING_MM}mm`, height: `${pageContentHeightPx * totalPages}px`, transform: `translateY(-${i * pageContentHeightPx}px)`, fontSize: `${fontSize}pt` }}>
                                <div dangerouslySetInnerHTML={{ __html: note.content }} />
                           </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
        <div className="bg-gray-800/50 px-6 py-4 flex justify-between items-center rounded-b-lg border-t border-gray-800">
          <span className="text-sm text-gray-400">Pages: {totalPages}</span>
          <div className="flex space-x-3">
              <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-700 text-white text-sm font-medium rounded-md hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-gray-500 transition-colors">
                Cancel
              </button>
              <button type="button" onClick={handleSave} disabled={isSaving || isGenerating} className="px-4 py-2 bg-gray-200 text-gray-900 text-sm font-medium rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-gray-400 transition-colors disabled:bg-gray-800 disabled:text-gray-500 disabled:cursor-not-allowed">
                {isSaving ? 'Saving...' : 'Save as PDF'}
              </button>
          </div>
        </div>
        <style>{`
          .prose-preview, .prose-measurer { line-height: 1.5; color: #000; font-family: sans-serif; }
          .prose-preview h1, .prose-measurer h1 { color: #000; font-size: 2em; margin-bottom: 1em; font-weight: bold; }
          .prose-preview h2, .prose-measurer h2 { color: #000; font-size: 1.5em; margin-bottom: 0.8em; font-weight: bold; }
          .prose-preview p, .prose-measurer p { margin-bottom: 1em; }
          .prose-preview a, .prose-measurer a { color: #000; text-decoration: underline; }
          .prose-preview strong, .prose-measurer strong { color: #000; font-weight: bold; }
          .prose-preview ul, .prose-preview ol, .prose-measurer ul, .prose-measurer ol { color: #000; padding-left: 1.5em; margin-bottom: 1em; }
          .prose-preview ul, .prose-measurer ul { list-style-type: disc; }
          .prose-preview ol, .prose-measurer ol { list-style-type: decimal; }
          .prose-preview * { color: #000 !important; }
        `}</style>
      </div>
    </div>
  );
};

export default PdfPreviewModal;
