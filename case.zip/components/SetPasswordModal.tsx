
import React, { useState, useEffect, useRef } from 'react';

interface SetPasswordModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSetPassword: (password: string) => void;
}

const SetPasswordModal: React.FC<SetPasswordModalProps> = ({ isOpen, onClose, onSetPassword }) => {
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  
  const passwordsMatch = password && password === confirm;
  const canSubmit = passwordsMatch && password.length >= 4;

  useEffect(() => {
    if (isOpen) {
      setPassword('');
      setConfirm('');
      setError('');
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen]);

  useEffect(() => {
    if (password && password.length > 0 && password.length < 4) {
        setError('Password must be at least 4 characters.');
    } else if (confirm && password !== confirm) {
        setError('Passwords do not match.');
    } else {
        setError('');
    }
  }, [password, confirm]);

  const handleSubmit = () => {
    if (canSubmit) {
      onSetPassword(password);
    }
  };

  if (!isOpen) return null;

  return (
    <div 
        className="fixed inset-0 z-[60] flex items-center justify-center bg-black bg-opacity-70 backdrop-blur-sm animate-fadeIn" 
        onClick={onClose}
        aria-labelledby="set-password-title"
        role="dialog"
        aria-modal="true"
    >
      <div className="bg-gray-900 rounded-lg shadow-xl w-full max-w-sm m-4" onClick={(e) => e.stopPropagation()}>
        <div className="p-6">
          <h2 id="set-password-title" className="text-xl font-bold text-white mb-4">Set Password</h2>
          <p className="text-sm text-gray-400 mb-4">Choose a password to protect your locked notes. Minimum 4 characters.</p>
          <div className="space-y-4">
            <input
              ref={inputRef}
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-gray-500"
              placeholder="New Password"
              aria-label="New Password"
            />
            <input
              type="password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
              className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-gray-500"
              placeholder="Confirm Password"
              aria-label="Confirm Password"
            />
          </div>
          {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
        </div>
        <div className="bg-gray-800/50 px-6 py-4 flex justify-end space-x-3 rounded-b-lg">
          <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-700 text-white rounded-md hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-gray-500">Cancel</button>
          <button type="button" onClick={handleSubmit} disabled={!canSubmit} className="px-4 py-2 bg-gray-200 text-gray-900 rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-gray-400 disabled:opacity-50">Set Password</button>
        </div>
      </div>
    </div>
  );
};

export default SetPasswordModal;
