
import React from 'react';
import XIcon from './icons/XIcon';
import SelectAllIcon from './icons/SelectAllIcon';

interface MultiSelectNavBarProps {
  selectedCount: number;
  totalCount: number;
  onCancel: () => void;
  onSelectAll: () => void;
}

const MultiSelectNavBar: React.FC<MultiSelectNavBarProps> = ({
  selectedCount,
  totalCount,
  onCancel,
  onSelectAll,
}) => {
  return (
    <header className="bg-black/80 backdrop-blur-lg sticky top-0 z-50 border-b border-gray-900 animate-fadeIn">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-4">
            <button
              type="button"
              onClick={onCancel}
              className="p-2 rounded-full text-gray-400 hover:bg-gray-800 hover:text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black focus:ring-gray-500 transition-colors"
              aria-label="Cancel selection"
            >
              <XIcon className="h-6 w-6" />
            </button>
            <span className="font-semibold text-lg text-white tabular-nums">
              {selectedCount}/{totalCount}
            </span>
          </div>
          <button
            type="button"
            onClick={onSelectAll}
            className="p-2 rounded-full text-gray-400 hover:bg-gray-800 hover:text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black focus:ring-gray-500 transition-colors"
            aria-label="Select all notes"
          >
            <SelectAllIcon className="h-6 w-6" />
          </button>
        </div>
      </div>
    </header>
  );
};

export default MultiSelectNavBar;
