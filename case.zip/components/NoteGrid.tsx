
import React from 'react';
import { Note } from '../App';
import NoteCard from './NoteCard';

interface NoteGridProps {
  notes: Note[];
  handleNotePress: (note: Note) => void;
  handleNoteLongPress: (noteId: string) => void;
  selectedNoteIds: Set<string>;
  layout: 'grid' | 'list';
  density: 'comfortable' | 'compact';
}

const NoteGrid: React.FC<NoteGridProps> = ({ notes, handleNotePress, handleNoteLongPress, selectedNoteIds, layout, density }) => {
  const containerClasses = layout === 'grid'
    ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4'
    : 'flex flex-col gap-3';

  return (
    <>
      {notes.length > 0 ? (
        <div className={containerClasses}>
          {notes.map(note => (
            <NoteCard 
              key={note.id} 
              note={note} 
              onClick={() => handleNotePress(note)}
              onLongPress={handleNoteLongPress}
              isSelected={selectedNoteIds.has(note.id)}
              layout={layout}
              density={density}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-10">
          <p className="text-gray-500">No notes here.</p>
        </div>
      )}
    </>
  );
};

export default NoteGrid;