
import React, { useState, useRef } from 'react';
import { Note, NoteVersion } from '../App';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import HistoryIcon from './icons/HistoryIcon';
import TrashIcon from './icons/TrashIcon';
import XIcon from './icons/XIcon';

interface VersionsPageProps {
  note: Note;
  onBack: () => void;
  onRollback: (noteId: string, version: NoteVersion) => void;
  onDelete: (noteId: string, version: NoteVersion) => void;
}

const VersionsPage: React.FC<VersionsPageProps> = ({ note, onBack, onRollback, onDelete }) => {
  const [viewingVersion, setViewingVersion] = useState<NoteVersion | null>(null);
  const [selectedVersion, setSelectedVersion] = useState<NoteVersion | null>(null);
  
  const timerRef = useRef<number>(0);
  const isLongPress = useRef(false);

  const createSnippet = (html: string, maxLength: number = 100): string => {
    if (!html) return 'No content';
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = html;
    const text = tempDiv.textContent || tempDiv.innerText || '';
    return text.length <= maxLength ? text : text.substring(0, maxLength).trim() + '...';
  };

  const formatDateTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString([], {
      dateStyle: 'medium',
      timeStyle: 'short',
    });
  };

  const handleRollbackClick = (version: NoteVersion) => {
    onRollback(note.id, version);
  };
  
  const handleDeleteClick = (version: NoteVersion) => {
    onDelete(note.id, version);
    setSelectedVersion(null); // Exit action mode after initiating delete
  };

  const handlePressStart = (version: NoteVersion) => {
    isLongPress.current = false;
    timerRef.current = window.setTimeout(() => {
      isLongPress.current = true;
      setSelectedVersion(version);
    }, 500);
  };

  const handlePressEnd = () => {
    clearTimeout(timerRef.current);
  };

  const handleClick = (version: NoteVersion) => {
    if (!isLongPress.current) {
        if(selectedVersion) {
           setSelectedVersion(null);
        } else {
           setViewingVersion(version);
        }
    }
  };

  const VersionListView = () => (
    <div className="flex flex-col h-full">
      {selectedVersion ? (
         <header className="sticky top-0 w-full bg-black/80 backdrop-blur-lg z-10 border-b border-gray-900 animate-fadeIn">
         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
           <div className="flex items-center justify-between h-16">
             <button
               type="button"
               onClick={() => setSelectedVersion(null)}
               className="p-2 rounded-full text-gray-400 hover:bg-gray-800 hover:text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black focus:ring-gray-500 transition-colors"
               aria-label="Cancel selection"
             >
               <XIcon className="h-6 w-6" />
             </button>
             <h1 className="text-lg font-semibold text-gray-200">1 Selected</h1>
             <div className="w-10"></div>
           </div>
         </div>
       </header>
      ) : (
      <header className="sticky top-0 w-full bg-black/80 backdrop-blur-lg z-10 border-b border-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center h-16">
            <button
              type="button"
              onClick={onBack}
              className="p-2 rounded-full text-gray-400 hover:bg-gray-800 hover:text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black focus:ring-gray-500 transition-colors"
              aria-label="Back to editor"
            >
              <ArrowLeftIcon className="h-6 w-6" />
            </button>
            <h1 className="text-lg font-semibold text-gray-200 ml-4 truncate">
              Version History for "{note.title}"
            </h1>
          </div>
        </div>
      </header>
      )}
      <main className={`flex-grow p-4 sm:p-6 lg:p-8 ${selectedVersion ? 'pb-24' : ''}`}>
        <div className="max-w-3xl mx-auto">
          {(!note.versions || note.versions.length === 0) ? (
            <p className="text-center text-gray-500">No saved versions for this note yet.</p>
          ) : (
            <ul className="space-y-4">
              {note.versions.map((version, index) => (
                <li key={index}>
                  <button
                    onClick={() => handleClick(version)}
                    onMouseDown={() => handlePressStart(version)}
                    onMouseUp={handlePressEnd}
                    onMouseLeave={handlePressEnd}
                    onTouchStart={() => handlePressStart(version)}
                    onTouchEnd={handlePressEnd}
                    className={`w-full p-4 bg-gray-900 border border-gray-800 rounded-lg text-left hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-gray-600 transition-colors ${selectedVersion?.savedAt === version.savedAt ? 'ring-2 ring-gray-500 border-gray-700 bg-gray-800/50' : ''}`}
                  >
                    <p className="font-semibold text-gray-300">{version.title}</p>
                    <p className="text-sm text-gray-400 mt-1 mb-2">{createSnippet(version.content)}</p>
                    <p className="text-xs text-gray-500">Saved on: {formatDateTime(version.savedAt)}</p>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </main>
      {selectedVersion && (
         <footer className="fixed bottom-0 left-0 right-0 bg-black/80 backdrop-blur-lg z-40 border-t border-gray-900 animate-fadeIn">
         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
           <div className="flex items-center justify-around h-16">
              <button
                type="button"
                onClick={() => handleRollbackClick(selectedVersion)}
                className="flex flex-col items-center p-2 rounded-lg text-gray-400 hover:bg-gray-800 hover:text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-gray-500 transition-colors w-24"
                aria-label="Roll back to this version"
              >
                <HistoryIcon className="h-6 w-6"/>
                <span className="text-xs mt-1">Roll back</span>
              </button>
               <button
                type="button"
                onClick={() => handleDeleteClick(selectedVersion)}
                className="flex flex-col items-center p-2 rounded-lg text-red-500 hover:bg-red-500/10 hover:text-red-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-red-500 transition-colors w-24"
                aria-label="Delete this version permanently"
              >
                <TrashIcon className="h-6 w-6"/>
                <span className="text-xs mt-1">Delete</span>
              </button>
           </div>
         </div>
       </footer>
      )}
    </div>
  );

  const VersionDetailView = () => {
    if (!viewingVersion) return null;
    return (
      <div className="flex flex-col h-full">
        <header className="sticky top-0 w-full bg-black/80 backdrop-blur-lg z-10 border-b border-gray-900">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center h-16">
              <button
                type="button"
                onClick={() => setViewingVersion(null)}
                className="p-2 rounded-full text-gray-400 hover:bg-gray-800 hover:text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black focus:ring-gray-500 transition-colors"
                aria-label="Back to version list"
              >
                <ArrowLeftIcon className="h-6 w-6" />
              </button>
              <div className="flex-1 text-center px-4">
                <h1 className="text-lg font-semibold text-gray-200 truncate">{viewingVersion.title}</h1>
                <p className="text-sm text-gray-500">Version from {formatDateTime(viewingVersion.savedAt)}</p>
              </div>
               <div className="w-10"></div>
            </div>
          </div>
        </header>
        <main className="flex-grow p-4 sm:p-6 lg:p-8 pb-24">
          <div
            className="prose prose-invert max-w-3xl mx-auto text-gray-300 text-lg"
            dangerouslySetInnerHTML={{ __html: viewingVersion.content }}
          />
        </main>
        <footer className="fixed bottom-0 left-0 right-0 bg-black/80 backdrop-blur-lg z-40 border-t border-gray-900">
           <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-center">
             <button
                type="button"
                onClick={() => handleRollbackClick(viewingVersion)}
                className="px-6 py-2 bg-gray-200 text-gray-900 text-sm font-medium rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black focus:ring-gray-400 transition-colors"
              >
                Roll back to this version
              </button>
           </div>
        </footer>
      </div>
    );
  };
  
  return (
    <div className="fixed inset-0 bg-black z-[55] animate-fadeIn overflow-y-auto">
      {viewingVersion ? <VersionDetailView /> : <VersionListView />}
    </div>
  );
};

export default VersionsPage;
