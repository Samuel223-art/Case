
import React, { useEffect, useRef } from 'react';
import XIcon from './icons/XIcon';
import ChevronUpIcon from './icons/ChevronUpIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';

interface FindBarProps {
  searchQuery: string;
  onSearchQueryChange: (query: string) => void;
  onClose: () => void;
  onNext: () => void;
  onPrev: () => void;
  currentMatchIndex: number;
  totalMatches: number;
}

const FindBar: React.FC<FindBarProps> = ({
  searchQuery,
  onSearchQueryChange,
  onClose,
  onNext,
  onPrev,
  currentMatchIndex,
  totalMatches,
}) => {
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
    inputRef.current?.select();
  }, []);
  
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (e.shiftKey) {
        onPrev();
      } else {
        onNext();
      }
    }
    if (e.key === 'Escape') {
        onClose();
    }
  };

  return (
    <div className="bg-gray-900/80 backdrop-blur-lg z-20 border-b border-gray-800 animate-fadeIn">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center h-14 space-x-4">
          <div className="relative flex-grow">
            <input
              ref={inputRef}
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchQueryChange(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Find in note..."
              className="w-full bg-transparent text-white placeholder-gray-500 focus:outline-none pr-8"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => onSearchQueryChange('')}
                className="absolute inset-y-0 right-0 flex items-center p-2 text-gray-500 hover:text-white"
                aria-label="Clear search"
              >
                <XIcon className="h-5 w-5" />
              </button>
            )}
          </div>
          <div className="flex items-center space-x-2 text-gray-400">
            <span className="text-sm w-16 text-center tabular-nums">
              {totalMatches > 0 ? `${currentMatchIndex + 1} / ${totalMatches}` : '0 / 0'}
            </span>
            <button
              type="button"
              onClick={onPrev}
              disabled={totalMatches === 0}
              className="p-1.5 rounded-full hover:bg-gray-800 disabled:opacity-50 disabled:cursor-not-allowed"
              aria-label="Previous match"
            >
              <ChevronUpIcon className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={onNext}
              disabled={totalMatches === 0}
              className="p-1.5 rounded-full hover:bg-gray-800 disabled:opacity-50 disabled:cursor-not-allowed"
              aria-label="Next match"
            >
              <ChevronDownIcon className="h-5 w-5" />
            </button>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-gray-800 text-gray-400"
            aria-label="Close find bar"
          >
            <XIcon className="h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default FindBar;
