
import React from 'react';
import { IconProps } from './IconProps';

const StrikethroughIcon: React.FC<IconProps> = ({ className }) => {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      className={className} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2.5" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    >
        <path d="M4 12h16" />
        <path d="M6 5.5c3.33 1 5 3 5 5s-1.67 4-5 5" />
        <path d="M18 18.5c-3.33-1-5-3-5-5s1.67-4 5-5" />
    </svg>
  );
};

export default StrikethroughIcon;
