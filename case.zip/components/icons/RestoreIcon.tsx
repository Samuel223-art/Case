
import React from 'react';
import { IconProps } from './IconProps';

const RestoreIcon: React.FC<IconProps> = ({ className }) => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m14 0H5" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 11V3m0 8l-4 4m4-4l4 4" />
    </svg>
  );
};

export default RestoreIcon;
