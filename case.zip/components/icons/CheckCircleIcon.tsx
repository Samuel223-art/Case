
import React from 'react';
import { IconProps } from './IconProps';

const CheckCircleIcon: React.FC<IconProps> = ({ className }) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      viewBox="0 0 24 24"
      fill="currentColor"
    >
      <path
        fillRule="evenodd"
        d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zM9.86 16.5l-3.36-3.36 1.41-1.41 1.95 1.95 4.24-4.24 1.41 1.41-5.65 5.65z"
        clipRule="evenodd"
      />
    </svg>
  );
};

export default CheckCircleIcon;
