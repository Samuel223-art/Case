
import React from 'react';
import { Settings } from '../App';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import SunIcon from './icons/SunIcon';
import MoonIcon from './icons/MoonIcon';
import DesktopIcon from './icons/DesktopIcon';
import LayoutGridIcon from './icons/LayoutGridIcon';
import LayoutListIcon from './icons/LayoutListIcon';
import ExportIcon from './icons/ExportIcon';
import ImportIcon from './icons/ImportIcon';
import TrashIcon from './icons/TrashIcon';

interface SettingsPageProps {
  onBack: () => void;
  settings: Settings;
  onSettingsChange: (newSettings: Partial<Settings>) => void;
  onExportData: () => void;
  onImportData: () => void;
  onClearAllData: () => void;
  onSetPassword: () => void;
  onRemovePassword: () => void;
  isPasswordSet: boolean;
}

const SettingsSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <section>
        <h2 className="text-xl font-bold text-gray-800 dark:text-gray-200 mb-4">{title}</h2>
        <div className="bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-800 divide-y divide-gray-200 dark:divide-gray-800">
            {children}
        </div>
    </section>
);

const SettingsRow: React.FC<{ title: string; description?: string; children: React.ReactNode }> = ({ title, description, children }) => (
    <div className="p-4 flex items-center justify-between">
        <div>
            <h3 className="font-semibold text-gray-800 dark:text-gray-200">{title}</h3>
            {description && <p className="text-sm text-gray-500 dark:text-gray-400">{description}</p>}
        </div>
        <div>{children}</div>
    </div>
);

type SegmentedControlOption<T> = { value: T; label?: string; icon?: React.ReactNode; };

function SegmentedControl<T extends string>({ options, value, onChange }: { options: SegmentedControlOption<T>[]; value: T; onChange: (value: T) => void; }) {
    return (
        <div className="flex items-center bg-gray-200 dark:bg-gray-800 p-1 rounded-lg">
            {options.map(option => (
                <button
                    key={option.value}
                    type="button"
                    onClick={() => onChange(option.value)}
                    className={`px-3 py-1 text-sm font-semibold rounded-md transition-colors ${value === option.value ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white' : 'text-gray-600 dark:text-gray-400 hover:bg-gray-300/50 dark:hover:bg-gray-700/50'}`}
                >
                    {option.icon || option.label}
                </button>
            ))}
        </div>
    );
}


const SettingsPage: React.FC<SettingsPageProps> = ({ 
    onBack, settings, onSettingsChange, onExportData, onImportData, onClearAllData, onSetPassword, onRemovePassword, isPasswordSet
 }) => {
    return (
        <div className="fixed inset-0 bg-gray-100 dark:bg-black z-50 animate-fadeIn flex flex-col">
            <header className="sticky top-0 w-full bg-white/80 dark:bg-black/80 backdrop-blur-lg z-10 border-b border-gray-200 dark:border-gray-900 flex-shrink-0">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex items-center h-16">
                        <button
                            type="button"
                            onClick={onBack}
                            className="p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-black focus:ring-gray-500 transition-colors"
                            aria-label="Back to notes"
                        >
                            <ArrowLeftIcon className="h-6 w-6" />
                        </button>
                        <h1 className="text-lg font-semibold text-gray-900 dark:text-gray-200 ml-4">Settings</h1>
                    </div>
                </div>
            </header>
            <main className="flex-grow p-4 sm:p-6 lg:p-8 overflow-y-auto">
                <div className="max-w-3xl mx-auto space-y-8 pb-8">
                    
                    <SettingsSection title="Appearance">
                        <SettingsRow title="Theme" description="Choose a light, dark or system theme.">
                            <SegmentedControl
                                value={settings.theme}
                                onChange={theme => onSettingsChange({ theme })}
                                options={[
                                    { value: 'light', icon: <SunIcon className="w-5 h-5" /> },
                                    { value: 'dark', icon: <MoonIcon className="w-5 h-5" /> },
                                    { value: 'system', icon: <DesktopIcon className="w-5 h-5" /> },
                                ]}
                            />
                        </SettingsRow>
                        <SettingsRow title="Note Layout" description="Display notes in a grid or a list.">
                             <SegmentedControl
                                value={settings.noteLayout}
                                onChange={noteLayout => onSettingsChange({ noteLayout })}
                                options={[
                                    { value: 'grid', icon: <LayoutGridIcon className="w-5 h-5" /> },
                                    { value: 'list', icon: <LayoutListIcon className="w-5 h-5" /> },
                                ]}
                            />
                        </SettingsRow>
                         <SettingsRow title="Note Density" description="Adjust the spacing of notes.">
                             <SegmentedControl
                                value={settings.noteDensity}
                                onChange={noteDensity => onSettingsChange({ noteDensity })}
                                options={[
                                    { value: 'comfortable', label: 'Comfortable' },
                                    { value: 'compact', label: 'Compact' },
                                ]}
                            />
                        </SettingsRow>
                    </SettingsSection>
                    
                    <SettingsSection title="Editor">
                        <SettingsRow title="Font Size" description="Set the default text size for notes.">
                             <SegmentedControl
                                value={settings.editorFontSize}
                                onChange={editorFontSize => onSettingsChange({ editorFontSize })}
                                options={[
                                    { value: 'small', label: 'Small' },
                                    { value: 'medium', label: 'Medium' },
                                    { value: 'large', label: 'Large' },
                                ]}
                            />
                        </SettingsRow>
                        <SettingsRow title="Font Family" description="Choose the default font for notes.">
                            <SegmentedControl
                                value={settings.editorFont}
                                onChange={editorFont => onSettingsChange({ editorFont })}
                                options={[
                                    { value: 'sans', label: 'Sans-Serif' },
                                    { value: 'serif', label: 'Serif' },
                                    { value: 'mono', label: 'Monospace' },
                                ]}
                            />
                        </SettingsRow>
                         <SettingsRow title="Show Word Count" description="Display word and character counts in the editor.">
                            <input
                                type="checkbox"
                                className="toggle-switch"
                                checked={settings.showWordCount}
                                onChange={e => onSettingsChange({ showWordCount: e.target.checked })}
                                aria-label="Toggle word count display"
                            />
                        </SettingsRow>
                    </SettingsSection>
                    
                    <SettingsSection title="Security">
                        <SettingsRow title="Password for Locked Notes" description={isPasswordSet ? "Change or remove your password." : "Set a password to lock notes."}>
                             <div className="flex items-center gap-2">
                                {isPasswordSet && <button onClick={onRemovePassword} className="px-3 py-1.5 text-sm font-semibold rounded-md text-red-600 hover:bg-red-500/10 transition-colors">Remove</button>}
                                <button onClick={onSetPassword} className="px-3 py-1.5 text-sm font-semibold rounded-md text-white bg-gray-800 dark:bg-gray-200 dark:text-gray-900 hover:bg-gray-700 dark:hover:bg-gray-300 transition-colors">
                                  {isPasswordSet ? 'Change' : 'Set Password'}
                                </button>
                             </div>
                        </SettingsRow>
                    </SettingsSection>

                    <SettingsSection title="Data Management">
                        <SettingsRow title="Export Data" description="Save all your notes and settings to a JSON file.">
                            <button onClick={onExportData} className="flex items-center gap-2 px-3 py-1.5 text-sm font-semibold rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-800 transition-colors">
                                <ExportIcon className="w-5 h-5"/>
                                <span>Export</span>
                            </button>
                        </SettingsRow>
                         <SettingsRow title="Import Data" description="Load notes and settings from a backup file.">
                             <button onClick={onImportData} className="flex items-center gap-2 px-3 py-1.5 text-sm font-semibold rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-800 transition-colors">
                                <ImportIcon className="w-5 h-5"/>
                                <span>Import</span>
                            </button>
                        </SettingsRow>
                        <SettingsRow title="Clear All Data" description="Permanently delete all notes, PDFs, and settings.">
                             <button onClick={onClearAllData} className="flex items-center gap-2 px-3 py-1.5 text-sm font-semibold rounded-md text-red-600 hover:bg-red-500/10 transition-colors">
                                <TrashIcon className="w-5 h-5"/>
                                <span>Clear Data</span>
                            </button>
                        </SettingsRow>
                    </SettingsSection>
                </div>
            </main>
            <style>{`
                .toggle-switch {
                    appearance: none;
                    width: 40px;
                    height: 24px;
                    background-color: #e5e7eb; /* gray-200 */
                    border-radius: 9999px;
                    position: relative;
                    cursor: pointer;
                    transition: background-color 0.2s ease-in-out;
                }
                .dark .toggle-switch {
                    background-color: #374151; /* dark:gray-700 */
                }
                .toggle-switch::before {
                    content: '';
                    position: absolute;
                    width: 18px;
                    height: 18px;
                    background-color: white;
                    border-radius: 9999px;
                    top: 3px;
                    left: 3px;
                    transition: transform 0.2s ease-in-out;
                }
                .toggle-switch:checked {
                    background-color: #4f46e5; /* indigo-600 */
                }
                .toggle-switch:checked::before {
                    transform: translateX(16px);
                }
            `}</style>
        </div>
    );
};

export default SettingsPage;